# TaskMaster-App
## lab26
### MY tasks page
![](/screenshots/p3.png)
## All tasks page
![](/screenshots/p4.png)
## Add Tasks page
![](/screenshots/p5.png)

## add some onBoarding stuff and styling my App
![](/screenshots/p1.png)
![](/screenshots/p2.png)


## lab27
 - **Add the ability to send data among different activities in your application using SharedPreferences and Intent**
 
### My Tasks
![](/screenshots/mytasks.png)
### add Task
![](/screenshots/addtask.png)
### all tasks
![](/screenshots/alltasks.png)
### setting
![](/screenshots/setting.png)
### task Detail
![](/screenshots/taskDetail.png)

## lab28
- **Add the ability to choose tasks from recyclerview and show it on another page**

### all tasks
![](/screenshots/alltasks-lab28.png)

### task Detail
![](/screenshots/taskDetails-rec.png)
![](/screenshots/taskdetail-rec-2.png)

### task Detail with normal button
![](/screenshots/taskDetail.png)

## lab29
- **Add the ability to choose tasks from recyclerview and show it from database**

### all tasks
![](/screenshots/All.png)
![](/screenshots/All2.png)


### task Detail
![](/screenshots/lab29-details.png)
![](/screenshots/lab29-details2.png)

### add task
![](/screenshots/lab29-add.png)

